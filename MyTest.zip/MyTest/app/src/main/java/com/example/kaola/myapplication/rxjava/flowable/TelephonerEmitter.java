package com.example.kaola.myapplication.rxjava.observable.backpressure;

import com.example.kaola.myapplication.rxjava.observable.Emitter;

/**
 * @ClassName TelephonerEmitter
 * @Description
 * 1. 打电话人的电话
 * @Author zhangchao
 * @Date 2020-02-02 09:43
 * @Version 1.0
 */
public interface TelephonerEmitter<T> extends Emitter<T> {
}
