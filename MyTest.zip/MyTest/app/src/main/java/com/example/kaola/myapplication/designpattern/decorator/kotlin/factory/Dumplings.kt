package com.example.kaola.myapplication.designpattern.decorator.kotlin.factory

/**
 * @author zhangchao on 2019-07-18.
 */

data class Dumplings(val name: String)