package com.example.kaola.myapplication.widget;

/******************************************
 * 类描述:
 *
 * @version: V1.0
 * @author: yangshaoning
 * @time: 2018-04-25 17:19
 ******************************************/
public interface CScaleWidgetInter {
    /**
     * 设置动画具体实现监听
     *
     * @param makeAnimationImpl
     */
    void setMakeAnimationImpl(MakeAnimationImpl makeAnimationImpl);
}
