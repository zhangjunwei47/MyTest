package com.example.kaola.myapplication.rxjava.observable;


/**
 * @ClassName CallerEmitter
 * @Description 打电话的人的电话
 * @Author zhangchao
 * @Date 2020-01-31 09:00
 * @Version 1.0
 */
public interface CallerEmitter<T> extends Emitter<T> {

}
