package com.example.kaola.myapplication.jvm;

public class MyTest {
    public MyTest() {
        System.out.println("加载MyTest完成....");
    }
}
