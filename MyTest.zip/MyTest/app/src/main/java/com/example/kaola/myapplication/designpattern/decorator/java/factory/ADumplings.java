package com.example.kaola.myapplication.designpattern.decorator.java.factory;

/**
 * @author zhangchao on 2019-07-18.
 */

public abstract class ADumplings {
    public abstract void makeDumplings();

    public abstract Dumplings getDumpling();
}
