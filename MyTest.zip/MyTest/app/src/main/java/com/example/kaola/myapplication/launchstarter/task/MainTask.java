package com.example.kaola.myapplication.launchstarter.task;

/**
 * @author zhangchao on 2019-09-09.
 */

public class MainTask {
}
