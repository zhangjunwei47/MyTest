package com.example.kaola.myapplication.designpattern.decorator.java.factory;

/**
 * @author zhangchao on 2019-07-18.
 */

public class Dumplings {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
