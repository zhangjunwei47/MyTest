package com.example.kaola.myapplication.kotlintest

/**
 * @author zhangchao on 2018/5/15.
 */

//class TestOne {
//    val holle:String = "hollo world!"
//}