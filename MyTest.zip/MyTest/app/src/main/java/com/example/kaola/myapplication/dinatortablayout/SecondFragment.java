package com.example.kaola.myapplication.dinatortablayout;

import android.support.v4.app.Fragment;

/**
 * @author zhangchao on 2018/9/6.
 */

public class SecondFragment extends Fragment {
}
