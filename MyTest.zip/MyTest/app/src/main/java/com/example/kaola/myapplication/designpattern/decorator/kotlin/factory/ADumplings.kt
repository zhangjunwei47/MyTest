package com.example.kaola.myapplication.designpattern.decorator.kotlin.factory

/**
 * @author zhangchao on 2019-07-18.
 */

abstract class ADumplings {
    abstract fun makeDumplings()
    abstract fun getDumplings(): Dumplings
}