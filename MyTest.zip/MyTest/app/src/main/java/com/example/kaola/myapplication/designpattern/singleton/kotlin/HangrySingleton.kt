package com.example.kaola.myapplication.designpattern.singleton.kotlin

/**
 * @author zhangchao on 2019-06-12.
 */

object HangrySingleton