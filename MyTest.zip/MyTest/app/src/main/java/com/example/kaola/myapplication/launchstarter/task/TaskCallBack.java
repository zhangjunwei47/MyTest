//package com.example.kaola.myapplication.launchstarter.task;
//
//public interface TaskCallBack {
//
//    void call();
//}
