package com.example.kaola.myapplication.network;

/**
 * @author zhangchao on 2019/3/5.
 */

public class RequestConstants {

    //测试接口路径
    public static final String BASE_URL_TEST_HOST = "http://testupgrade.byd.com:8055/ota-api/";
    public static final String BASE_URL_TEST_IP = "http:// 10.54.145.107:8055/ota-api/";

    // 正式接口路径
    public static final String BASE_URL_HOST = "http://productupgrade.byd.com:8055/ota-api/";

}
